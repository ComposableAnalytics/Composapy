Composable's API binding for python.

README to be expanded as development continues.
